"""Shared model: corner labelling, 12 quarter-turn perms,
orientation twists derived from geometry, BFS, transition tables."""
import numpy as np, itertools
from collections import deque

MOVE_NAMES = ["U","U'","D","D'","F","F'","B","B'","L","L'","R","R'"]
POS_NAMES = ["URF","UFL","ULB","UBR","DFR","DLF","DBL","DRB"]
# coordinates: R=+x, B=+y (F=-y), U=+z
COORD = [(1,-1,1),(-1,-1,1),(-1,1,1),(1,1,1),(1,-1,-1),(-1,-1,-1),(-1,1,-1),(1,1,-1)]

def _make_perm(cycle):
    p = list(range(8)); a,b,c,d = cycle
    p[b]=a; p[c]=b; p[d]=c; p[a]=d
    return tuple(p)
def _invert(perm):
    inv=[0]*8
    for i,s in enumerate(perm): inv[s]=i
    return tuple(inv)
CYCLES = {"U":(0,3,2,1),"D":(4,5,6,7),"F":(0,1,5,4),"B":(3,2,6,7),"L":(1,2,6,5),"R":(0,4,7,3)}
MOVE_PERMS=[]
for f in "UDFBLR":
    p=_make_perm(CYCLES[f]); MOVE_PERMS += [p,_invert(p)]
# new_state[j] = old_state[p[j]]  (position j receives the cubie that was at position p[j])

def apply_move(state, m):
    p = MOVE_PERMS[m]; return tuple(state[p[j]] for j in range(8))

def parity(perm):
    perm=list(perm); s=0; seen=[False]*8
    for i in range(8):
        if not seen[i]:
            j=i; L=0
            while not seen[j]: seen[j]=True; j=perm[j]; L+=1
            s += L-1
    return s%2

def bfs(moves_idx=range(12), perms=None):
    perms = perms or MOVE_PERMS
    start=tuple(range(8)); s2i={start:0}; i2s=[start]; dist=[0]; dq=deque([start])
    while dq:
        s=dq.popleft(); d=dist[s2i[s]]
        for m in moves_idx:
            p=perms[m]; n=tuple(s[p[j]] for j in range(8))
            if n not in s2i:
                s2i[n]=len(i2s); i2s.append(n); dist.append(d+1); dq.append(n)
    return s2i, i2s, np.array(dist)

def trans_table(s2i, i2s, perms):
    return np.array([[s2i[tuple(s[p[j]] for j in range(8))] for p in perms] for s in i2s], dtype=np.int64)

# ---- orientation twists from geometry ----
def _rot(axis, sign):
    # 90deg rotation about axis (0,1,2) with sign +1 = counterclockwise looking from +axis
    R=np.zeros((3,3),int); a=axis; b=(axis+1)%3; c=(axis+2)%3
    R[a,a]=1; R[b,c]=-sign; R[c,b]=sign  # rotates b->c when sign=+1
    return R
FACE_AXIS={"U":(2,1),"D":(2,-1),"R":(0,1),"L":(0,-1),"B":(1,1),"F":(1,-1)}
def facelet_order(c):
    n=[np.array([0,0,c[2]]),np.array([c[0],0,0]),np.array([0,c[1],0])]  # start with z facelet
    if round(np.linalg.det(np.array(n)))<0: n=[n[0],n[2],n[1]]
    return n
def move_rotation(face, perm):
    axis,_=FACE_AXIS[face]
    for sign in (1,-1):
        R=_rot(axis,sign)
        if all(tuple(R@np.array(COORD[perm[j]]))==COORD[j] for j in range(8) if COORD[perm[j]]!=COORD[j] or True
               if COORD[j][axis]==FACE_AXIS[face][1]):
            return R
    raise ValueError
def twists(m):
    """tw[j]: twist added to the orientation stored at position j, i.e. o'[j]=o[p[j]]+tw[j] (mod 3)."""
    face=MOVE_NAMES[m][0]; p=MOVE_PERMS[m]; R=move_rotation(face,p); axis,side=FACE_AXIS[face]
    tw=[0]*8
    for j in range(8):
        if COORD[j][axis]!=side: continue
        a=p[j]; ref=R@facelet_order(COORD[a])[0]
        order=facelet_order(COORD[j])
        tw[j]=[k for k in range(3) if (order[k]==ref).all()][0]
    return tw
TWISTS=[twists(m) for m in range(12)]
