import os, numpy as np, json, math, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from cube import *
plt.rcParams.update({"font.family":"serif","font.serif":["Times New Roman","DejaVu Serif"],"mathtext.fontset":"stix",
    "font.size":10,"axes.labelsize":10.5,"xtick.labelsize":9.5,"ytick.labelsize":9.5,"legend.fontsize":9,
    "axes.spines.top":False,"axes.spines.right":False,"savefig.dpi":300,"figure.dpi":100})
os.makedirs("figures",exist_ok=True)
C=["#1f4e9c","#c0392b","#2e8b57","#d68910","#7d3c98","#555555"]
s2i,i2s,dist=bfs(); N=len(i2s); T=trans_table(s2i,i2s,MOVE_PERMS)
par=np.array([parity(s) for s in i2s])
def stepf(P,T,probs,ps):
    Q=ps*P
    for m,w in enumerate(probs):
        R=np.empty_like(P); R[T[:,m]]=P; Q+=(1-ps)*w*R
    return Q
def run(T,probs,ps,n):
    P=np.zeros(T.shape[0]); P[0]=1; out=[P]
    for _ in range(n): P=stepf(P,T,probs,ps); out.append(P)
    return out
tv=lambda P: 0.5*np.abs(P-1/len(P)).sum()
U12=[1/12]*12
Ps=run(T,U12,0.5,90); lazy=np.array([tv(P) for P in Ps])
# k-move exact walk vs parity coset
Pk=run(T,U12,0.0,40); kc=np.array([1.0]+[0.5*np.abs(Pk[k]-np.where(par==k%2,2/N,0)).sum() for k in range(1,41)])
full18=json.load(open("results/full_htm18.json")); fq=json.load(open("results/full_qtm_coset.json"))
hp=[]
from cube import _make_perm,_invert
for f in "UDFBLR":
    p=_make_perm(CYCLES[f]); hp+=[p,tuple(p[p[j]] for j in range(8)),_invert(p)]
T18=trans_table(s2i,i2s,hp); P18=run(T18,[1/18]*18,0.0,30); c18=np.array([tv(P) for P in P18])

# Figure 1: primary result, exact k-move walk (coset) + lazy chain on expected-move axis; log panel
fig,(a,b)=plt.subplots(2,1,figsize=(6.5,6.6))
k=np.arange(41)
a.plot(k,kc,"o-",color=C[0],ms=4,lw=1.8,label="exact $k$-move walk (vs. parity coset)")
a.plot(np.arange(91)*0.5,lazy,"-",color=C[1],lw=1.8,label="lazy chain, $p_{stay}=0.5$ (ticks × 0.5)")
a.axhline(0.25,ls="--",color="k",lw=1); a.axvline(10,ls=":",color=C[0],lw=1.2)
a.set_xlim(0,40); a.set_ylim(0,1.03); a.set_xlabel("number of quarter turns (expected, for the lazy chain)"); a.set_ylabel("total variation distance")
a.text(10.5,0.28,"$t_{mix}=10$",color=C[0],fontsize=10); a.legend(frameon=False,loc="upper right"); a.text(-0.09,1.0,"(a)",transform=a.transAxes,fontsize=11,weight="bold")
t=np.arange(91)
b.semilogy(t,lazy,color=C[1],lw=1.8,label="exact TV, lazy chain")
lam=0.9151439358935056; b.semilogy(t[30:],lazy[40]*lam**(t[30:]-40),"--",color="k",lw=1,label=r"slope of $\lambda_*^{\,t}$, $\lambda_*=0.915$")
for e in [0.5,0.25,0.1,0.01]:
    tm=int(np.argmax(lazy<e)); b.axhline(e,color="#999999",lw=0.7,ls=":"); b.plot(tm,lazy[tm],"s",color=C[0],ms=5)
    b.text(tm+1.5,e*1.12,f"ε={e}: {tm}",fontsize=9)
b.set_xlabel("ticks of the lazy chain ($p_{stay}=0.5$)"); b.set_ylabel("total variation distance (log scale)"); b.set_xlim(0,90); b.set_ylim(1e-3,1.2)
b.legend(frameon=False,loc="center right",bbox_to_anchor=(1,0.6),fontsize=9); b.text(-0.09,1.0,"(b)",transform=b.transAxes,fontsize=11,weight="bold")
fig.tight_layout(); fig.savefig("figures/fig1.png"); plt.close(fig)

# Figure 2: laziness sweep, ticks vs expected moves
fig,(a,b)=plt.subplots(2,1,figsize=(6.5,6.6))
for ps,c in zip([0.15,0.25,0.5,0.75,0.9],C):
    cc=np.array([tv(P) for P in run(T,U12,ps,320)]); tm=int(np.argmax(cc<0.25))
    a.plot(cc,color=c,lw=1.8,label=f"$p_{{stay}}$={ps}  ({tm} ticks)")
    b.plot(np.arange(321)*(1-ps),cc,color=c,lw=1.8,label=f"$p_{{stay}}$={ps}  ({tm*(1-ps):.2f} moves)")
for ax,xl in [(a,"ticks"),(b,"expected quarter turns = ticks × (1 − $p_{stay}$)")]:
    ax.axhline(0.25,ls="--",color="k",lw=1); ax.set_xlabel(xl); ax.set_ylabel("total variation distance"); ax.set_ylim(0,1.03); ax.legend(frameon=False,fontsize=8.5)
a.set_xlim(0,140); b.set_xlim(0,30)
a.text(-0.09,1.0,"(a)",transform=a.transAxes,fontsize=11,weight="bold"); b.text(-0.09,1.0,"(b)",transform=b.transAxes,fontsize=11,weight="bold")
fig.tight_layout(); fig.savefig("figures/fig2.png"); plt.close(fig)

# Figure 3: move sets
fig,ax=plt.subplots(figsize=(6.3,3.5))
ax.plot(lazy[:81],color=C[0],lw=2,label="12 moves, uniform (20 ticks)")
s2,i2,d2=bfs([0,1,2,3,4,5,6,7]); T8=trans_table(s2,i2,[MOVE_PERMS[m] for m in range(8)])
c8=np.array([tv(P) for P in run(T8,[1/8]*8,0.5,80)]); ax.plot(c8,color=C[1],lw=2,label="8 moves, no L/R (31 ticks)")
cw=np.array([tv(P) for P in run(T,[2/16]*4+[1/16]*8,0.5,80)]); ax.plot(cw,color=C[2],lw=2,ls="-.",label="12 moves, U/D double weight (22 ticks)")
ax.axhline(0.25,ls="--",color="k",lw=1); ax.set_xlabel("ticks of the lazy chain ($p_{stay}=0.5$)"); ax.set_ylabel("total variation distance"); ax.set_xlim(0,80); ax.set_ylim(0,1.03); ax.legend(frameon=False)
fig.tight_layout(); fig.savefig("figures/fig3.png"); plt.close(fig)

# Figure 4: entropy / KL / Pinsker
Hs=np.array([-(P[P>0]*np.log2(P[P>0])).sum() for P in Ps[:61]]); D=math.log2(N)-Hs
fig,(a,b)=plt.subplots(2,1,figsize=(6.5,6.6))
a.plot(Hs,color=C[2],lw=2); a.axhline(math.log2(N),ls="--",color="k",lw=1); a.axhline(0.9*math.log2(N),ls=":",color=C[3],lw=1.2)
a.axvline(12,ls=":",color=C[3],lw=1.2); a.text(13,6,"90% of $\\log_2 N$\nreached at t = 12",fontsize=9.5)
a.set_xlabel("ticks ($p_{stay}=0.5$)"); a.set_ylabel("Shannon entropy $H(P_t)$ (bits)"); a.set_xlim(0,60); a.set_ylim(0,16.2)
b.plot(lazy[:61],color=C[0],lw=2,label="exact TV distance")
b.plot(np.minimum(1,np.sqrt(D*math.log(2)/2)),color=C[1],lw=2,ls="--",label=r"Pinsker bound $\sqrt{D\,\ln 2/2}$")
b.axhline(0.25,ls=":",color="k",lw=1); b.set_xlabel("ticks ($p_{stay}=0.5$)"); b.set_ylabel("distance to uniform"); b.set_xlim(0,60); b.set_ylim(0,1.05); b.legend(frameon=False)
a.text(-0.09,1.0,"(a)",transform=a.transAxes,fontsize=11,weight="bold"); b.text(-0.09,1.0,"(b)",transform=b.transAxes,fontsize=11,weight="bold")
fig.tight_layout(); fig.savefig("figures/fig4.png"); plt.close(fig)

# Figure 5: distance-grouped snapshots
ub=np.bincount(dist)/N
fig,axes=plt.subplots(2,3,figsize=(6.5,4.6),sharex=True)
for ax,tt in zip(axes.flat,[0,2,5,10,20,60]):
    bins=np.bincount(dist,weights=Ps[tt]); gtv=0.5*np.abs(bins-ub).sum()
    ax.bar(range(9),bins,color=C[0],width=0.7); ax.plot(range(9),ub,"o--",color=C[1],ms=3.5,lw=1.4)
    ax.set_ylim(0,1.05); ax.text(0.97,0.93,f"t = {tt}\ngrouped TV = {gtv:.3f}\nfull TV = {tv(Ps[tt]):.3f}",transform=ax.transAxes,ha="right",va="top",fontsize=8)
for ax in axes[1]: ax.set_xlabel("distance from solved")
for ax in axes.flat: ax.set_xticks(range(0,9,2))
for ax in axes[:,0]: ax.set_ylabel("probability mass")
fig.tight_layout(); fig.savefig("figures/fig5.png"); plt.close(fig)

# Figure 6: projection vs full cube
fig,(a,b)=plt.subplots(2,1,figsize=(6.5,6.6))
k18=np.arange(0,31); f18=np.array([1.0]+[full18[str(i)] for i in range(1,31)])
a.plot(k18,c18,"o-",color=C[0],ms=4,lw=1.8,label="corner permutation")
a.plot(k18,f18,"s-",color=C[1],ms=4,lw=1.8,label="full 2×2×2 (fixed frame)")
a.axhline(0.25,ls="--",color="k",lw=1); a.axvline(11,ls=":",color=C[0]); a.axvline(19,ls=":",color=C[1])
a.text(11.4,0.85,"11",color=C[0],fontsize=10); a.text(19.4,0.85,"19",color=C[1],fontsize=10)
a.set_xlabel("random moves (18-move chain)"); a.set_ylabel("total variation distance"); a.set_xlim(0,30); a.set_ylim(0,1.03); a.legend(frameon=False,loc="center right",bbox_to_anchor=(1,0.6),fontsize=9)
nq=max(int(x) for x in fq); kq=np.arange(0,nq+1); fqa=np.array([1.0]+[fq[str(i)] for i in range(1,nq+1)])
b.plot(k[:nq+1],kc[:nq+1],"o-",color=C[0],ms=4,lw=1.8,label="corner permutation")
b.plot(kq,fqa,"s-",color=C[1],ms=4,lw=1.8,label="full 2×2×2 (fixed frame)")
tq=int(np.argmax(fqa<=0.25))
b.axhline(0.25,ls="--",color="k",lw=1); b.axvline(10,ls=":",color=C[0]); b.axvline(tq,ls=":",color=C[1])
b.text(10.4,0.85,"10",color=C[0],fontsize=10); b.text(tq+0.4,0.85,str(tq),color=C[1],fontsize=10)
b.set_xlabel("quarter turns (12-move chain, vs. parity coset)"); b.set_ylabel("total variation distance"); b.set_xlim(0,nq); b.set_ylim(0,1.03); b.legend(frameon=False,loc="center right",bbox_to_anchor=(1,0.6),fontsize=9)
a.text(-0.09,1.0,"(a)",transform=a.transAxes,fontsize=11,weight="bold"); b.text(-0.09,1.0,"(b)",transform=b.transAxes,fontsize=11,weight="bold")
fig.tight_layout(); fig.savefig("figures/fig6.png"); plt.close(fig)
print("done; full qtm tmix", tq, "c18@10,11",c18[10],c18[11])
