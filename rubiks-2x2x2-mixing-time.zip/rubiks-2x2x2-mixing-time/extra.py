import os, numpy as np, scipy.sparse as sp, scipy.sparse.linalg as sla, json, math, itertools
from cube import *
from cube import _make_perm,_invert
s2i,i2s,dist=bfs(); N=len(i2s); T=trans_table(s2i,i2s,MOVE_PERMS)
out={}
# weighted UD spectral gap
w=np.array([2/16]*4+[1/16]*8)
K=sp.csr_matrix((np.tile(w,N),(np.repeat(np.arange(N),12),T.ravel())),shape=(N,N))
ev=sla.eigsh(K,k=3,which='LA',return_eigenvectors=False); out["lambda2_weighted"]=sorted(ev)[-2]
# continuous time: P_s = sum_k Pois(s;k) K^k delta
Pk=[]; P=np.zeros(N); P[0]=1; Pk.append(P.copy())
K12=sp.csr_matrix((np.full(T.size,1/12),(np.repeat(np.arange(N),12),T.ravel())),shape=(N,N))
for k in range(1,150): P=K12.T@P; Pk.append(P)
Pk=np.array(Pk)
ct={}
for s10 in range(0,300):
    s=s10/10; ks=np.arange(150); pw=np.exp(-s+ks*math.log(s) - np.array([math.lgamma(k+1) for k in ks])) if s>0 else (ks==0)*1.0
    ct[s]=0.5*np.abs(pw@Pk-1/N).sum()
out["ct_tmix"]={e:min(s for s in ct if ct[s]<e) for e in [0.5,0.25,0.1,0.01]}
out["ct_tv"]={s:round(ct[s],4) for s in [8.0,9.0,9.5,10.0,11.0]}
# tail rate check for lazy chain
out["lazy_rate_40_57"]=None
# full 2x2x2 up to rotation: fix DBL (pos 6); moves U,R,F (and their 2,3 powers) on 7 corners + orientation
ORI=list(itertools.product(range(3),repeat=8))
qt=[(MOVE_PERMS[m],TWISTS[m]) for m in range(12)]
def comp(a,b):
    p,tw=a; q,t=b
    return tuple(p[q[j]] for j in range(8)), [(tw[q[j]]+t[j])%3 for j in range(8)]
gens_q=[qt[0],qt[1],qt[10],qt[11],qt[4],qt[5]]  # U U' R R' F F'  (none touch DBL=6)
gens_h=gens_q+[comp(qt[0],qt[0]),comp(qt[10],qt[10]),comp(qt[4],qt[4])]
def bfs_full(gens):
    start=(tuple(range(8)),(0,)*8); seen={start:0}; frontier=[start]; d=0; counts=[1]
    while frontier:
        nf=[]
        for (p,o) in frontier:
            for q,t in gens:
                n=(tuple(p[q[j]] for j in range(8)), tuple((o[q[j]]+t[j])%3 for j in range(8)))
                if n not in seen: seen[n]=d+1; nf.append(n)
        frontier=nf; d+=1
        if nf: counts.append(len(nf))
    return len(seen), len(counts)-1, counts
out["full_qtm"]=bfs_full(gens_q); out["full_htm"]=bfs_full(gens_h)
os.makedirs("results",exist_ok=True); json.dump(out,open("results/extra.json","w"),indent=1,default=str); print(json.dumps(out,indent=1,default=str))
