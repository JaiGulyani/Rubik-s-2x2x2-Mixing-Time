import os, numpy as np, scipy.sparse as sp, scipy.sparse.linalg as sla, json, math, time
from cube import *
from cube import _make_perm, _invert
t0=time.time()
s2i,i2s,dist=bfs(); N=len(i2s)
T=trans_table(s2i,i2s,MOVE_PERMS)
out={"N":N,"dist_counts":np.bincount(dist).tolist(),"diameter":int(dist.max())}
par=np.array([parity(s) for s in i2s])
def step(P, T, probs, p_stay):
    Q=p_stay*P
    for m,w in enumerate(probs):
        if w: np.add.at(Q, T[:,m], (1-p_stay)*w*P)  # bijection, so plain assignment works too
    return Q
def step_fast(P,T,probs,p_stay):
    Q=p_stay*P
    for m,w in enumerate(probs):
        if w:
            R=np.empty_like(P); R[T[:,m]]=P; Q+= (1-p_stay)*w*R
    return Q
def tv(P,pi=None):
    n=len(P); return 0.5*np.abs(P-(1/n if pi is None else pi)).sum()
def curve(T,probs,p_stay,n,start=0):
    P=np.zeros(T.shape[0]); P[start]=1; c=[tv(P)]; Ps=[P.copy()]
    for _ in range(n): P=step_fast(P,T,probs,p_stay); c.append(tv(P)); Ps.append(P)
    return np.array(c),Ps
def tmix(c,eps,strict=True):
    for t,v in enumerate(c):
        if (v<eps if strict else v<=eps): return t
    return None
U12=[1/12]*12
c,Ps=curve(T,U12,0.5,300)
out["tv_p05"]={t:round(float(c[t]),6) for t in [0,5,8,10,12,15,19,20,21,25,30,31,40,50,57,60]}
out["tmix_eps"]={e:tmix(c,e) for e in [0.75,0.5,0.25,0.1,0.01]}
out["tmix_eps_leq"]={e:tmix(c,e,False) for e in [0.75,0.5,0.25,0.1,0.01]}
# entropy / KL / Pinsker
H=lambda P: float(-(P[P>0]*np.log2(P[P>0])).sum())
out["H"]={t:round(H(Ps[t]),4) for t in [12,20,30,60]}
out["H_frac"]={t:round(H(Ps[t])/math.log2(N),5) for t in [11,12,20,60]}
out["t_H90"]=next(t for t in range(300) if H(Ps[t])>=0.9*math.log2(N))
out["KL"]={t:round(math.log2(N)-H(Ps[t]),4) for t in [12,20]}
out["pinsker"]={t:round(math.sqrt((math.log2(N)-H(Ps[t]))*math.log(2)/2),4) for t in [12,20]}
out["tv_at"]={t:round(float(c[t]),4) for t in [12,20]}
# grouped-by-distance TV (Figure 6 labels)
ub=np.bincount(dist)/N
out["grouped_tv"]={t:round(0.5*float(np.abs(np.bincount(dist,weights=Ps[t])-ub).sum()),3) for t in [0,2,5,10,20,60]}
out["t0_bar"]=float(np.bincount(dist,weights=Ps[0])[0])
# laziness sweep, long window
sweep={}
for ps in [0.15,0.25,0.5,0.75,0.9]:
    cc,_=curve(T,U12,ps,400); tm=tmix(cc,0.25); sweep[ps]=(tm, round(tm*(1-ps),2))
out["sweep"]=sweep
# move sets
sets={}
for name,allowed in {"noLR":[0,1,2,3,4,5,6,7],"noFB":[0,1,2,3,8,9,10,11],"noUD":[4,5,6,7,8,9,10,11]}.items():
    s2,i2,d2=bfs(allowed); Tt=trans_table(s2,i2,[MOVE_PERMS[m] for m in allowed])
    cc,_=curve(Tt,[1/8]*8,0.5,200); sets[name]=(len(i2),int(d2.max()),tmix(cc,0.25),np.bincount(d2).tolist())
    if name=="noLR":
        K=sp.csr_matrix((np.full(Tt.size,1/8),(np.repeat(np.arange(len(i2)),8),Tt.ravel())),shape=(len(i2),)*2)
        ev=sla.eigsh(K,k=4,which='LA',return_eigenvectors=False); out["lambda2_8move"]=sorted(ev)[-2]
w=[2/16]*4+[1/16]*8
cc,_=curve(T,w,0.5,200); sets["weightedUD"]=(N,None,tmix(cc,0.25))
out["movesets"]=sets
# spectral
K=sp.csr_matrix((np.full(T.size,1/12),(np.repeat(np.arange(N),12),T.ravel())),shape=(N,N))
evs=sla.eigsh(K,k=6,which='LA',return_eigenvectors=False); evsm=sla.eigsh(K,k=3,which='SA',return_eigenvectors=False)
out["top_eigs"]=sorted(evs.tolist(),reverse=True); out["bottom_eigs"]=sorted(evsm.tolist())
lam2=sorted(evs)[-2]; out["lambda2"]=lam2
lam_lazy=0.5+0.5*lam2; out["lazy_lambda2"]=lam_lazy; out["t_rel_lazy"]=1/(1-lam_lazy)
# second-largest in absolute value excluding +-1
out["lambda2_abs_excl_bipartite"]=max(abs(x) for x in list(evs)+list(evsm) if abs(abs(x)-1)>1e-9)
# exact k-move walk vs uniform on parity coset
P=np.zeros(N); P[0]=1; kc={}
for k in range(1,31):
    P=step_fast(P,T,U12,0.0)
    coset=(par==k%2); pi=np.where(coset,2/N,0.0)
    kc[k]=round(0.5*float(np.abs(P-pi).sum()),4)
    if k in (9,10,11): out[f"k{k}_full_uniform_tv"]=round(tv(P),4)
out["kmove_coset_tv"]=kc
out["kmove_tmix"]={e:next(k for k in kc if kc[k]<e) for e in [0.5,0.25,0.1,0.01]}
# 18-move chain (quarter, half, three-quarter per face, uniform) on corner perms
hp=[]
for f in "UDFBLR":
    p=_make_perm(CYCLES[f]); p2=tuple(p[p[j]] for j in range(8)); hp += [p,p2,_invert(p)]
T18=trans_table(s2i,i2s,hp)
P=np.zeros(N); P[0]=1; c18={}
for k in range(1,31):
    P=step_fast(P,T18,[1/18]*18,0.0); c18[k]=round(tv(P),4)
out["htm18_tv"]=c18; out["htm18_tmix"]=next(k for k in c18 if c18[k]<0.25)
# checks: scrambled start (U, F, L from solved), mass conservation, relaxation-time bounds (Eq. 4)
s=tuple(range(8))
for m in (0,4,8): s=apply_move(s,m)
cs,_=curve(T,U12,0.5,300,start=s2i[s])
out["scrambled_start_max_tv_diff"]=float(np.abs(cs-c).max())
out["mass_err_200"]=float(max(abs(Ps[t].sum()-1) for t in range(201)))
tr=out["t_rel_lazy"]
out["tmix_bounds_eps025"]=(math.ceil((tr-1)*math.log(2)), math.floor(tr*math.log(4*N)))
out["runtime_s"]=round(time.time()-t0,1)
os.makedirs("results",exist_ok=True); json.dump(out,open("results/perm_results.json","w"),indent=1,default=str)
print(json.dumps(out,indent=1,default=str))
