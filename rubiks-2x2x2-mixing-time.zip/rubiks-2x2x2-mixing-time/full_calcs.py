"""Orientation-inclusive, fixed-frame 2x2x2 chain: 8!*3^7 = 88,179,840 states.
P is stored as a (40320 perms) x (2187 orientations) float64 array."""
import os, numpy as np, json, time, sys, itertools
from cube import *
from cube import _make_perm, _invert
t0=time.time()
s2i,i2s,dist=bfs(); NP=len(i2s)
par=np.array([parity(s) for s in i2s])
# orientation coordinate: o[0..6] base-3 digits, o[7] = -(sum) mod 3
ORI=[o+((-sum(o))%3,) for o in itertools.product(range(3),repeat=7)]
o2i={o:i for i,o in enumerate(ORI)}; NO=len(ORI)
def compose_tw(perms_tws):
    """compose a list of (perm, tw) moves applied in order -> (perm, tw)"""
    p=tuple(range(8)); tw=[0]*8
    for q,t in perms_tws:
        # new o'[j] = o[q[j]] + t[j]; current state o = o0[p[j]]+tw[j]
        p2=tuple(p[q[j]] for j in range(8)); tw2=[(tw[q[j]]+t[j])%3 for j in range(8)]
        p,tw=p2,tw2
    return p,tw
def tables(moves):
    Tp=np.empty((NP,len(moves)),np.int64); To=np.empty((NO,len(moves)),np.int64)
    for m,(p,tw) in enumerate(moves):
        for i,s in enumerate(i2s): Tp[i,m]=s2i[tuple(s[p[j]] for j in range(8))]
        for i,o in enumerate(ORI): To[i,m]=o2i[tuple((o[p[j]]+tw[j])%3 for j in range(8))]
    # inverse maps for gather form
    iTp=np.empty_like(Tp); iTo=np.empty_like(To)
    for m in range(len(moves)):
        iTp[Tp[:,m],m]=np.arange(NP); iTo[To[:,m],m]=np.arange(NO)
    return iTp,iTo
qt=[(MOVE_PERMS[m],TWISTS[m]) for m in range(12)]
m18=[]
for f in range(6):
    a=qt[2*f]; m18 += [a, compose_tw([a,a]), qt[2*f+1]]
def run(moves, p_stay, nsteps, coset=False, tag=""):
    iTp,iTo=tables(moves); nm=len(moves)
    P=np.zeros((NP,NO)); P[0,0]=1.0; res={}
    Ntot=NP*NO
    for t in range(1,nsteps+1):
        Q=p_stay*P
        for m in range(nm):
            Q+= ((1-p_stay)/nm)*np.take(np.take(P,iTp[:,m],axis=0),iTo[:,m],axis=1)
        P=Q
        if coset:
            pi_row=np.where(par==(t%2),2.0/Ntot,0.0)[:,None]
            tv=0.5*np.abs(P-pi_row).sum()
        else:
            tv=0.5*np.abs(P-1.0/Ntot).sum()
        res[t]=float(tv)
        print(tag,t,round(tv,5),"support",int((P>0).sum()) if t<16 else "", "mass-1",float(P.sum()-1), round(time.time()-t0),flush=True)
        if tv<0.005: break
    return res
which=sys.argv[1]
if which=="htm18": r=run(m18,0.0,30,tag="18move")
elif which=="qtm_coset": r=run(qt,0.0,40,coset=True,tag="12move-coset")
elif which=="qtm_lazy": r=run(qt,0.5,90,tag="12move-lazy0.5")
os.makedirs("results",exist_ok=True); json.dump(r,open(f"results/full_{which}.json","w"),indent=1)
