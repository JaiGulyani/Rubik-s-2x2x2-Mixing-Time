# Exact Mixing Time of the 2×2×2 Rubik's Cube Random Walk

Code and data that reproduce every number, table and figure in the paper.

All results are computed exactly by propagating the full probability distribution over the state space (up to double-precision round-off, ~10⁻¹⁵). No random sampling is used anywhere.

## Files

| File | What it does | Runtime (Apple M5, 16 GB) |
|---|---|---|
| `cube.py` | Shared model: corner labelling (0 URF … 7 DRB), the 12 quarter-turn permutations, orientation twists derived from cube geometry, BFS, transition tables | — |
| `perm_calcs.py` | All 40,320-state corner-permutation results: TV curves, t_mix at several thresholds, laziness sweep, move-set comparison, spectral gap, entropy/KL/Pinsker, distance-grouped TV, exact k-move walk vs. parity class, 18-move chain → `results/perm_results.json` | ~5 s |
| `extra.py` | Continuous-time chain, weighted move-set spectral gap, full 2×2×2 BFS (3,674,160 positions; diameters 14 QTM / 11 HTM) → `results/extra.json` | ~1 min |
| `full_calcs.py` | Exact chain on the full fixed-frame corner group (88,179,840 states, stored as 40,320 × 2,187). Run with `htm18`, `qtm_coset` or `qtm_lazy` → `results/full_*.json` | ~1.5–3 min each, ~2.5 GB RAM |
| `figures.py` | Figures 1–6 at print size (6.5 in wide, 300 dpi) → `figures/` | ~1 min |
| `results/` | Output JSON files used in the paper | |
| `figures/` | Figures as they appear in the paper | |

## Usage

Requires Python ≥ 3.10.

```bash
pip install -r requirements.txt

python perm_calcs.py
python extra.py
python full_calcs.py htm18
python full_calcs.py qtm_coset
python full_calcs.py qtm_lazy
python figures.py          # needs results/full_htm18.json and results/full_qtm_coset.json
```

Run all scripts from the repository root.

## Key results

- Corner permutation mixes (TV < 1/4) after **10** quarter turns (exact k-move walk vs. parity class), **20** ticks of the lazy chain at p_stay = 0.5, and **10.4** in continuous time.
- Second-largest eigenvalue λ₂ = 0.830; relaxation time t_rel = 11.8 ticks (lazy chain).
- Under the 18-move chain: **11** moves (corner permutation) vs. **19** moves (full corner group, including orientation).
